package com.lti.droplets.config;

public class EndpointUrlConfig {

	public final static String RULES_CHECK_TRANSACTION_ELIGIBILITY_FOR_RULE = "/rulesInitialization/checkTransactionEligibilityForRule";
	public final static String TRANSACTIONMANAGER_SAVE_TRANSACTION="/transactionDetails/saveTransaction";
}
